# Bài tập tiếng Việt

Trang web này chứa bài tập điền từ vào chỗ trống gồm 30 câu.

Mở `index.html` trong trình duyệt hoặc triển khai bằng GitHub Pages.